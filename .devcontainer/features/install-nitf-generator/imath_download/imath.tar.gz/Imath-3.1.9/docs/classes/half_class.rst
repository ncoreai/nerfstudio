..
  SPDX-License-Identifier: BSD-3-Clause
  Copyright Contributors to the OpenEXR Project.

The half Class
##############

.. doxygenclass:: Imath::half
   :undoc-members:
   :members:

.. doxygenfunction:: operator<<(std::ostream& os, Imath::half h)

.. doxygenfunction:: operator>>(std::istream&, Imath::half&)

                     
